// Particles Animation (Existing Particles)
const canvas = document.getElementById('particles-canvas');
const ctx = canvas.getContext('2d');
let particlesArray = [];
let mouse = { x: null, y: null, radius: 120 };

if (canvas) {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });

    window.addEventListener('mousemove', (event) => {
        mouse.x = event.x;
        mouse.y = event.y;
    });

    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2 + 0.5;
            this.baseX = this.x;
            this.baseY = this.y;
            this.speedX = Math.random() * 0.2 - 0.1;
            this.speedY = Math.random() * 0.2 - 0.1;
            this.opacity = Math.random() * 0.4 + 0.2;
            this.glow = 0;
        }

        update() {
            this.x += this.speedX;
            this.y += this.speedY;

            // Interaction with mouse
            let dx = mouse.x - this.x;
            let dy = mouse.y - this.y;
            let distance = Math.sqrt(dx * dx + dy * dy);
            if (distance < mouse.radius) {
                let forceDirectionX = dx / distance;
                let forceDirectionY = dy / distance;
                let maxDistance = mouse.radius;
                let force = (maxDistance - distance) / maxDistance;
                this.speedX -= forceDirectionX * force * 1.5;
                this.speedY -= forceDirectionY * force * 1.5;
                this.glow = Math.min(force * 0.5, 0.5);
            } else {
                this.glow = Math.max(this.glow - 0.01, 0);
            }

            if (this.size > 0.1) this.size -= 0.002;

            if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
            if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;
        }

        draw() {
            ctx.fillStyle = `rgba(139, 92, 246, ${this.opacity + this.glow})`;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    function initParticles() {
        particlesArray = [];
        const numberOfParticles = (canvas.width * canvas.height) / 20000;
        for (let i = 0; i < numberOfParticles; i++) {
            particlesArray.push(new Particle());
        }
    }

    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < particlesArray.length; i++) {
            particlesArray[i].update();
            particlesArray[i].draw();

            for (let j = i; j < particlesArray.length; j++) {
                const dx = particlesArray[i].x - particlesArray[j].x;
                const dy = particlesArray[i].y - particlesArray[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                if (distance < 120) {
                    ctx.strokeStyle = `rgba(139, 92, 246, ${particlesArray[i].opacity * 0.2})`;
                    ctx.lineWidth = 0.3;
                    ctx.beginPath();
                    ctx.moveTo(particlesArray[i].x, particlesArray[i].y);
                    ctx.lineTo(particlesArray[j].x, particlesArray[j].y);
                    ctx.stroke();
                }
            }

            if (particlesArray[i].size <= 0.1) {
                particlesArray.splice(i, 1);
                i--;
                particlesArray.push(new Particle());
            }
        }
        requestAnimationFrame(animateParticles);
    }

    initParticles();
    animateParticles();
} else {
    console.error("Particles canvas element not found!");
}

// Meteor Shower Animation
const meteorCanvas = document.getElementById('meteor-canvas');
const meteorCtx = meteorCanvas.getContext('2d');
let meteorsArray = [];

if (meteorCanvas) {
    meteorCanvas.width = window.innerWidth;
    meteorCanvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        meteorCanvas.width = window.innerWidth;
        meteorCanvas.height = window.innerHeight;
    });

    class Meteor {
        constructor() {
            this.x = Math.random() * meteorCanvas.width;
            this.y = -20;
            this.size = Math.random() * 2 + 1;
            this.speedX = Math.random() * 2 + 1; // Move para a direita
            this.speedY = Math.random() * 4 + 2; // Move para baixo
            this.opacity = Math.random() * 0.5 + 0.5;
            this.life = 1;
            this.trailLength = Math.random() * 10 + 5;
        }

        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            this.life -= 0.01;
            this.opacity = this.life;

            if (this.y > meteorCanvas.height || this.x > meteorCanvas.width || this.life <= 0) {
                this.reset();
            }
        }

        reset() {
            this.x = Math.random() * meteorCanvas.width;
            this.y = -20;
            this.size = Math.random() * 2 + 1;
            this.speedX = Math.random() * 2 + 1;
            this.speedY = Math.random() * 4 + 2;
            this.opacity = Math.random() * 0.5 + 0.5;
            this.life = 1;
            this.trailLength = Math.random() * 10 + 5;
        }

        draw() {
            meteorCtx.beginPath();
            meteorCtx.moveTo(this.x, this.y);
            const trailX = this.x - this.speedX * this.trailLength;
            const trailY = this.y - this.speedY * this.trailLength;
            meteorCtx.lineTo(trailX, trailY);
            meteorCtx.strokeStyle = `rgba(255, 255, 255, ${this.opacity})`;
            meteorCtx.lineWidth = this.size;
            meteorCtx.stroke();

            // Draw the meteor head with a glow
            meteorCtx.beginPath();
            meteorCtx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            meteorCtx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
            meteorCtx.shadowBlur = 10;
            meteorCtx.shadowColor = 'rgba(255, 255, 255, 0.5)';
            meteorCtx.fill();
            meteorCtx.shadowBlur = 0;
        }
    }

    function initMeteors() {
        meteorsArray = [];
        const numberOfMeteors = 10; // Número de meteoros
        for (let i = 0; i < numberOfMeteors; i++) {
            meteorsArray.push(new Meteor());
        }
    }

    function animateMeteors() {
        meteorCtx.clearRect(0, 0, meteorCanvas.width, meteorCanvas.height);
        for (let i = 0; i < meteorsArray.length; i++) {
            meteorsArray[i].update();
            meteorsArray[i].draw();
        }
        requestAnimationFrame(animateMeteors);
    }

    initMeteors();
    animateMeteors();
} else {
    console.error("Meteor canvas element not found!");
}

// Fly-in animation on scroll
const flyIns = document.querySelectorAll('.fly-in');
console.log("Fly-in elements found:", flyIns.length);

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            console.log("Element intersecting:", entry.target.id || entry.target);
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1 });

flyIns.forEach(element => {
    observer.observe(element);
});

// Verificar se os ícones dos bots carregaram corretamente
document.querySelectorAll('.bot-icon').forEach(icon => {
    const bgImage = window.getComputedStyle(icon).backgroundImage;
    const imageUrl = bgImage.slice(5, -2); // Extrai a URL da propriedade background-image
    const img = new Image();
    img.src = imageUrl;
    img.onload = () => {
        console.log(`Ícone carregado com sucesso: ${imageUrl}`);
    };
    img.onerror = () => {
        console.error(`Erro ao carregar o ícone: ${imageUrl}`);
        // Fallback: definir um fundo de cor sólida caso a imagem não carregue
        icon.style.background = 'linear-gradient(45deg, #8b5cf6, #a78bfa)';
        icon.style.backgroundSize = 'cover';
    };
});

// Redirecionar ao clicar no card de bot
document.querySelectorAll('.bot-card').forEach(card => {
    card.addEventListener('click', () => {
        const botId = card.getAttribute('data-bot-id');
        if (botId) {
            window.location.href = `bot-details/details.html?bot=${botId}`;
        }
    });
});

// Navbar scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    } else {
        console.error("Navbar element not found!");
    }
});

// Parallax effect
const botsSection = document.querySelector('.bots-section');
const teamSection = document.querySelector('.team-section');

window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    if (botsSection) {
        botsSection.style.setProperty('--scroll-y', `${scrollY}px`);
    }
    if (teamSection) {
        teamSection.style.setProperty('--scroll-y', `${scrollY}px`);
    }
});

// Smooth scroll for nav links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        } else {
            console.error("Target element not found for anchor:", this.getAttribute('href'));
        }
    });
});

// Mostrar/esconder a seta de rolagem até a seção Bots
const scrollArrow = document.querySelector('.scroll-arrow');
const botsSectionForArrow = document.querySelector('#bots');

const arrowObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        console.log("IntersectionObserver - Bots section visibility:", entry.isIntersecting, "Intersection ratio:", entry.intersectionRatio);
        if (entry.isIntersecting) {
            scrollArrow.classList.add('hidden');
        } else {
            scrollArrow.classList.remove('hidden');
        }
    });
}, { 
    threshold: 0.05, // Reduzido para ser mais sensível
    rootMargin: '-50px 0px 0px 0px' // Antecipa o desaparecimento
});

if (scrollArrow && botsSectionForArrow) {
    arrowObserver.observe(botsSectionForArrow);
} else {
    console.error("Scroll arrow or bots section not found!");
    console.log("Scroll arrow:", scrollArrow);
    console.log("Bots section:", botsSectionForArrow);
}