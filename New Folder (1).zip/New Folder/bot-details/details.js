// Dados dos bots
const botsData = {
    safeguard: {
        title: "Bot de Moderação - SafeGuard",
        description: "SafeGuard é um bot de moderação avançado projetado para manter seu servidor Discord seguro e organizado. Ele oferece ferramentas poderosas para gerenciar membros, filtrar mensagens e automatizar tarefas administrativas.",
        image: "https://via.placeholder.com/800x300.png?text=SafeGuard+Bot",
        features: [
            "Automoderação para filtrar mensagens indesejadas",
            "Comandos de ban, kick e mute",
            "Registro de ações de moderação",
            "Sistema de avisos com punições automáticas"
        ],
        commands: [
            "!ban @user [motivo] - Bane um usuário do servidor",
            "!kick @user [motivo] - Expulsa um usuário do servidor",
            "!mute @user [tempo] - Silencia um usuário por um tempo",
            "!clear [quantidade] - Limpa mensagens do canal"
        ],
        addLink: "#"
    },
    melodybot: {
        title: "Bot de Música - MelodyBot",
        description: "MelodyBot traz a melhor experiência musical para o seu servidor Discord. Toque músicas de alta qualidade do Spotify, YouTube e SoundCloud com comandos simples e intuitivos.",
        image: "https://via.placeholder.com/800x300.png?text=MelodyBot",
        features: [
            "Suporte a playlists do Spotify e YouTube",
            "Controle de volume e fila de músicas",
            "Pesquisa de músicas por nome ou URL",
            "Efeitos de áudio (bass boost, nightcore, etc.)"
        ],
        commands: [
            "!play [nome/URL] - Toca uma música ou playlist",
            "!skip - Pula a música atual",
            "!queue - Mostra a fila de músicas",
            "!volume [0-100] - Ajusta o volume"
        ],
        addLink: "#"
    },
    funplay: {
        title: "Bot de Jogos - FunPlay",
        description: "FunPlay adiciona diversão ao seu servidor com jogos interativos e minigames. Desafie seus amigos em trivia, jogo da velha e muito mais, com um sistema de ranking para competições.",
        image: "https://via.placeholder.com/800x300.png?text=FunPlay+Bot",
        features: [
            "Trivia com várias categorias",
            "Jogo da velha e outros minigames",
            "Sistema de ranking e pontos",
            "Eventos de jogos semanais"
        ],
        commands: [
            "!trivia - Inicia um jogo de trivia",
            "!tictactoe @user - Desafia um usuário para jogo da velha",
            "!rank - Mostra o ranking do servidor",
            "!event - Mostra os eventos de jogos ativos"
        ],
        addLink: "#"
    }
};

// Carregar dados do bot com base no parâmetro da URL
const urlParams = new URLSearchParams(window.location.search);
const botId = urlParams.get('bot');
const bot = botsData[botId];

if (bot) {
    document.getElementById('details-title').textContent = bot.title;
    document.getElementById('details-description').textContent = bot.description;
    document.getElementById('details-image').style.backgroundImage = `url('${bot.image}')`;

    // Preencher funcionalidades
    const featuresList = document.getElementById('details-features');
    bot.features.forEach(feature => {
        const li = document.createElement('li');
        li.textContent = feature;
        featuresList.appendChild(li);
    });

    // Preencher comandos
    const commandsList = document.getElementById('details-commands');
    bot.commands.forEach(command => {
        const li = document.createElement('li');
        li.textContent = command;
        commandsList.appendChild(li);
    });

    // Preencher link
    const addLink = document.getElementById('details-add-link');
    addLink.href = bot.addLink;
} else {
    document.querySelector('.details-content').innerHTML = '<h2>Bot não encontrado</h2><p>Desculpe, o bot solicitado não foi encontrado.</p>';
}

// Particles Animation
const canvas = document.getElementById('details-particles-canvas');
const ctx = canvas.getContext('2d');
let particlesArray = [];
let mouse = { x: null, y: null, radius: 120 };

if (canvas) {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });

    window.addEventListener('mousemove', (event) => {
        mouse.x = event.x;
        mouse.y = event.y;
    });

    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2 + 0.5;
            this.baseX = this.x;
            this.baseY = this.y;
            this.speedX = Math.random() * 0.2 - 0.1;
            this.speedY = Math.random() * 0.2 - 0.1;
            this.opacity = Math.random() * 0.4 + 0.2;
            this.glow = 0;
        }

        update() {
            this.x += this.speedX;
            this.y += this.speedY;

            // Interaction with mouse
            let dx = mouse.x - this.x;
            let dy = mouse.y - this.y;
            let distance = Math.sqrt(dx * dx + dy * dy);
            if (distance < mouse.radius) {
                let forceDirectionX = dx / distance;
                let forceDirectionY = dy / distance;
                let maxDistance = mouse.radius;
                let force = (maxDistance - distance) / maxDistance;
                this.speedX -= forceDirectionX * force * 1.5;
                this.speedY -= forceDirectionY * force * 1.5;
                this.glow = Math.min(force * 0.5, 0.5);
            } else {
                this.glow = Math.max(this.glow - 0.01, 0);
            }

            if (this.size > 0.1) this.size -= 0.002;

            if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
            if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;
        }

        draw() {
            ctx.fillStyle = `rgba(139, 92, 246, ${this.opacity + this.glow})`;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    function initParticles() {
        particlesArray = [];
        const numberOfParticles = (canvas.width * canvas.height) / 20000;
        for (let i = 0; i < numberOfParticles; i++) {
            particlesArray.push(new Particle());
        }
    }

    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < particlesArray.length; i++) {
            particlesArray[i].update();
            particlesArray[i].draw();

            for (let j = i; j < particlesArray.length; j++) {
                const dx = particlesArray[i].x - particlesArray[j].x;
                const dy = particlesArray[i].y - particlesArray[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                if (distance < 120) {
                    ctx.strokeStyle = `rgba(139, 92, 246, ${particlesArray[i].opacity * 0.2})`;
                    ctx.lineWidth = 0.3;
                    ctx.beginPath();
                    ctx.moveTo(particlesArray[i].x, particlesArray[i].y);
                    ctx.lineTo(particlesArray[j].x, particlesArray[j].y);
                    ctx.stroke();
                }
            }

            if (particlesArray[i].size <= 0.1) {
                particlesArray.splice(i, 1);
                i--;
                particlesArray.push(new Particle());
            }
        }
        requestAnimationFrame(animateParticles);
    }

    initParticles();
    animateParticles();
} else {
    console.error("Canvas element not found!");
}

// Fly-in animation on scroll
const flyIns = document.querySelectorAll('.fly-in');
console.log("Fly-in elements found:", flyIns.length);

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            console.log("Element intersecting:", entry.target.id || entry.target);
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1 });

flyIns.forEach(element => {
    observer.observe(element);
});

// Header scroll effect
window.addEventListener('scroll', () => {
    const header = document.querySelector('.details-header');
    if (header) {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    } else {
        console.error("Header element not found!");
    }
});